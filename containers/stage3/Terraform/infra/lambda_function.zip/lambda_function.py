import logging
import boto3
import pymysql
import json
from botocore.exceptions import BotoCoreError, ClientError

# Set up logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def get_db_credentials(secret_name, region_name):
    logger.info("retrieving vals at %s", secret_name)
    try:
        client = boto3.client(service_name='secretsmanager', region_name=region_name)
        logger.info("got client")
        logger.info(client)
        response = client.get_secret_value(SecretId=secret_name)
        logger.info("got response")
        logger.info(response)
    except ClientError as e:
        logger.error(f"Failed to retrieve secret: {e}")
        raise e

    if 'SecretString' in response:
        logger.info("secretstring in response")
        secret_dict = json.loads(response['SecretString'])
        logger.info("make dict")
        return secret_dict['username'], secret_dict['password']
    else:
        error_msg = 'Secret is binary, expected JSON string'
        logger.error(error_msg)
        raise ValueError(error_msg)

def create_tables(rds_endpoint, db_name, user_table_name, app_table_name, db_root_username, db_root_password, db_user_username, db_user_password):
    logger.info("Creating tables...")
    try:
        connection = pymysql.connect(
            host=rds_endpoint,
            user=db_root_username,
            password=db_root_password,
            db=db_name,
            cursorclass=pymysql.cursors.DictCursor
        )
    except pymysql.MySQLError as e:
        logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
        logger.error(e)
        return

    with connection.cursor() as cursor:
        try:
            logger.info("Creating User table...")
            sql = f"""
                CREATE TABLE `{user_table_name}` (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(255) NOT NULL UNIQUE,
                    password VARCHAR(255) NOT NULL
                );
            """
            cursor.execute(sql)

            logger.info("Creating App table...")
            sql = f"""
                CREATE TABLE `{app_table_name}` (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    fortune TEXT NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES `{user_table_name}`(id)
                );
            """
            cursor.execute(sql)

            logger.info("Creating User...")
            sql = f"""
                CREATE USER '{db_user_username}' IDENTIFIED BY '{db_user_password}';
            """
            cursor.execute(sql)

            logger.info("Granting User perms...")
            sql = f"""
                GRANT SELECT, INSERT, UPDATE, DELETE ON {db_name}.* TO '{db_user_username}';
            """
            cursor.execute(sql)
            connection.commit()
        except Exception as e:
            logger.error(f"Failed to execute SQL: {e}")
            connection.rollback()  # Roll back the transaction if there was an error
        finally:
            connection.close()

def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event, indent=2)}")
    rds_endpoint = event['rds_endpoint']
    db_root_username, db_root_password = get_db_credentials(event['db_root_secret'], event['region'])
    db_user_username, db_user_password = get_db_credentials(event['db_user_secret'], event['region'])
    db_name = event['db_name']
    user_table_name = event['user_table_name']
    app_table_name = event['app_table_name']
    logger.info(f"Using RDS endpoint: {rds_endpoint}")
    create_tables(rds_endpoint, db_name, user_table_name, app_table_name, db_root_username, db_root_password, db_user_username, db_user_password)
    return {
        'statusCode': 200,
        'body': json.dumps('Tables created successfully')
    }
